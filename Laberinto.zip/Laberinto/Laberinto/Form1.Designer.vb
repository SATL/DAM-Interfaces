﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.finishLabel = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.finishLabel)
        Me.Panel1.Controls.Add(Me.Label46)
        Me.Panel1.Controls.Add(Me.Label45)
        Me.Panel1.Controls.Add(Me.Label44)
        Me.Panel1.Controls.Add(Me.Label43)
        Me.Panel1.Controls.Add(Me.Label42)
        Me.Panel1.Controls.Add(Me.Label41)
        Me.Panel1.Controls.Add(Me.Label40)
        Me.Panel1.Controls.Add(Me.Label39)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.Label37)
        Me.Panel1.Controls.Add(Me.Label36)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.Label34)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Label27)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(610, 587)
        Me.Panel1.TabIndex = 0
        '
        'finishLabel
        '
        Me.finishLabel.BackColor = System.Drawing.Color.DarkCyan
        Me.finishLabel.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.finishLabel.Location = New System.Drawing.Point(526, 521)
        Me.finishLabel.Name = "finishLabel"
        Me.finishLabel.Size = New System.Drawing.Size(68, 46)
        Me.finishLabel.TabIndex = 46
        Me.finishLabel.Text = "Meta"
        Me.finishLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label46
        '
        Me.Label46.BackColor = System.Drawing.Color.Aqua
        Me.Label46.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label46.Location = New System.Drawing.Point(454, 88)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(31, 79)
        Me.Label46.TabIndex = 45
        '
        'Label45
        '
        Me.Label45.BackColor = System.Drawing.Color.Aqua
        Me.Label45.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label45.Location = New System.Drawing.Point(414, 14)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(96, 23)
        Me.Label45.TabIndex = 44
        '
        'Label44
        '
        Me.Label44.BackColor = System.Drawing.Color.Aqua
        Me.Label44.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label44.Location = New System.Drawing.Point(512, 105)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(96, 23)
        Me.Label44.TabIndex = 43
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.Aqua
        Me.Label43.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label43.Location = New System.Drawing.Point(3, 23)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(123, 23)
        Me.Label43.TabIndex = 42
        '
        'Label42
        '
        Me.Label42.BackColor = System.Drawing.Color.Aqua
        Me.Label42.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label42.Location = New System.Drawing.Point(328, 105)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(72, 23)
        Me.Label42.TabIndex = 41
        '
        'Label41
        '
        Me.Label41.BackColor = System.Drawing.Color.Aqua
        Me.Label41.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label41.Location = New System.Drawing.Point(388, 14)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(31, 114)
        Me.Label41.TabIndex = 40
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.Color.Aqua
        Me.Label40.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label40.Location = New System.Drawing.Point(454, 65)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(89, 23)
        Me.Label40.TabIndex = 39
        '
        'Label39
        '
        Me.Label39.BackColor = System.Drawing.Color.Aqua
        Me.Label39.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label39.Location = New System.Drawing.Point(479, 249)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(31, 55)
        Me.Label39.TabIndex = 38
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.Color.Aqua
        Me.Label38.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label38.Location = New System.Drawing.Point(417, 330)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(93, 23)
        Me.Label38.TabIndex = 37
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.Aqua
        Me.Label37.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label37.Location = New System.Drawing.Point(406, 236)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(81, 23)
        Me.Label37.TabIndex = 36
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.Aqua
        Me.Label36.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label36.Location = New System.Drawing.Point(421, 167)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(187, 23)
        Me.Label36.TabIndex = 35
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.Aqua
        Me.Label35.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label35.Location = New System.Drawing.Point(388, 368)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(187, 23)
        Me.Label35.TabIndex = 34
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.Aqua
        Me.Label34.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label34.Location = New System.Drawing.Point(479, 174)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(31, 85)
        Me.Label34.TabIndex = 33
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.Aqua
        Me.Label33.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label33.Location = New System.Drawing.Point(160, -5)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(31, 93)
        Me.Label33.TabIndex = 32
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.Color.Aqua
        Me.Label32.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label32.Location = New System.Drawing.Point(220, 236)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(72, 23)
        Me.Label32.TabIndex = 31
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.Aqua
        Me.Label31.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label31.Location = New System.Drawing.Point(328, 226)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(31, 68)
        Me.Label31.TabIndex = 30
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.Aqua
        Me.Label30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label30.Location = New System.Drawing.Point(261, 68)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(31, 122)
        Me.Label30.TabIndex = 29
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.Aqua
        Me.Label29.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label29.Location = New System.Drawing.Point(204, 122)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(31, 195)
        Me.Label29.TabIndex = 28
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.Aqua
        Me.Label28.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label28.Location = New System.Drawing.Point(544, 255)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(31, 239)
        Me.Label28.TabIndex = 27
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.Aqua
        Me.Label27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label27.Location = New System.Drawing.Point(388, 317)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(31, 68)
        Me.Label27.TabIndex = 26
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.Aqua
        Me.Label26.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label26.Location = New System.Drawing.Point(328, 368)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(31, 68)
        Me.Label26.TabIndex = 25
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Aqua
        Me.Label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label25.Location = New System.Drawing.Point(349, 413)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(226, 23)
        Me.Label25.TabIndex = 24
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Aqua
        Me.Label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label24.Location = New System.Drawing.Point(479, 465)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(31, 118)
        Me.Label24.TabIndex = 23
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Aqua
        Me.Label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label23.Location = New System.Drawing.Point(417, 426)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(31, 118)
        Me.Label23.TabIndex = 22
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Aqua
        Me.Label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label22.Location = New System.Drawing.Point(232, 494)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(187, 23)
        Me.Label22.TabIndex = 21
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Aqua
        Me.Label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label21.Location = New System.Drawing.Point(261, 294)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(158, 23)
        Me.Label21.TabIndex = 20
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Aqua
        Me.Label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label20.Location = New System.Drawing.Point(160, 521)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(75, 23)
        Me.Label20.TabIndex = 19
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.Aqua
        Me.Label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label19.Location = New System.Drawing.Point(204, 556)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(187, 23)
        Me.Label19.TabIndex = 18
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.Aqua
        Me.Label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label18.Location = New System.Drawing.Point(204, 402)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(31, 154)
        Me.Label18.TabIndex = 17
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Aqua
        Me.Label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label17.Location = New System.Drawing.Point(261, 317)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(31, 119)
        Me.Label17.TabIndex = 16
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Aqua
        Me.Label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label16.Location = New System.Drawing.Point(261, 167)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(187, 23)
        Me.Label16.TabIndex = 15
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Aqua
        Me.Label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label15.Location = New System.Drawing.Point(95, 122)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(187, 23)
        Me.Label15.TabIndex = 14
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Aqua
        Me.Label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label14.Location = New System.Drawing.Point(95, 145)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(31, 68)
        Me.Label14.TabIndex = 13
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Aqua
        Me.Label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label13.Location = New System.Drawing.Point(105, 281)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(63, 23)
        Me.Label13.TabIndex = 12
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Aqua
        Me.Label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label12.Location = New System.Drawing.Point(137, 213)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(31, 68)
        Me.Label12.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Aqua
        Me.Label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label11.Location = New System.Drawing.Point(339, 23)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(31, 68)
        Me.Label11.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Aqua
        Me.Label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label10.Location = New System.Drawing.Point(105, 346)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(187, 23)
        Me.Label10.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Aqua
        Me.Label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label9.Location = New System.Drawing.Point(37, 521)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 62)
        Me.Label9.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Aqua
        Me.Label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label8.Location = New System.Drawing.Point(95, 494)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 62)
        Me.Label8.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Aqua
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label7.Location = New System.Drawing.Point(37, 471)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(131, 23)
        Me.Label7.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Aqua
        Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label6.Location = New System.Drawing.Point(37, 236)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 200)
        Me.Label6.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Aqua
        Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label5.Location = New System.Drawing.Point(37, 213)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(131, 23)
        Me.Label5.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Aqua
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label4.Location = New System.Drawing.Point(65, 413)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(103, 23)
        Me.Label4.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Aqua
        Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label3.Location = New System.Drawing.Point(37, 91)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 85)
        Me.Label3.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Aqua
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Location = New System.Drawing.Point(19, 167)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 23)
        Me.Label2.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Aqua
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Location = New System.Drawing.Point(37, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 23)
        Me.Label1.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(634, 611)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Laberinto"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents finishLabel As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
