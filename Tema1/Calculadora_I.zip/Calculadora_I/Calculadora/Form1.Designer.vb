﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button0 = New System.Windows.Forms.Button()
        Me.NumberLabel = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.ButtonMore = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.ButtonMinus = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ButtonMult = New System.Windows.Forms.Button()
        Me.ButtonPoint = New System.Windows.Forms.Button()
        Me.ButtonEqual = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.ButtonCE = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button0
        '
        Me.Button0.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button0.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button0.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button0.Location = New System.Drawing.Point(8, 331)
        Me.Button0.Name = "Button0"
        Me.Button0.Size = New System.Drawing.Size(89, 56)
        Me.Button0.TabIndex = 1
        Me.Button0.Text = "0"
        Me.Button0.UseVisualStyleBackColor = False
        '
        'NumberLabel
        '
        Me.NumberLabel.AutoSize = True
        Me.TableLayoutPanel1.SetColumnSpan(Me.NumberLabel, 4)
        Me.NumberLabel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NumberLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumberLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.NumberLabel.Location = New System.Drawing.Point(8, 5)
        Me.NumberLabel.Name = "NumberLabel"
        Me.NumberLabel.Padding = New System.Windows.Forms.Padding(0, 50, 0, 0)
        Me.NumberLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NumberLabel.Size = New System.Drawing.Size(375, 91)
        Me.NumberLabel.TabIndex = 0
        Me.NumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button7.Location = New System.Drawing.Point(8, 157)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(89, 52)
        Me.Button7.TabIndex = 2
        Me.Button7.Text = "7"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button8.Location = New System.Drawing.Point(103, 157)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(89, 52)
        Me.Button8.TabIndex = 3
        Me.Button8.Text = "8"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button9.Location = New System.Drawing.Point(198, 157)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(89, 52)
        Me.Button9.TabIndex = 4
        Me.Button9.Text = "9"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'ButtonMore
        '
        Me.ButtonMore.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.ButtonMore.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ButtonMore.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMore.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMore.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonMore.Location = New System.Drawing.Point(293, 157)
        Me.ButtonMore.Name = "ButtonMore"
        Me.ButtonMore.Size = New System.Drawing.Size(90, 52)
        Me.ButtonMore.TabIndex = 5
        Me.ButtonMore.Text = "+"
        Me.ButtonMore.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button4.Location = New System.Drawing.Point(8, 215)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(89, 52)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "4"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button5.Location = New System.Drawing.Point(103, 215)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(89, 52)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = "5"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button6.Location = New System.Drawing.Point(198, 215)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(89, 52)
        Me.Button6.TabIndex = 8
        Me.Button6.Text = "6"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'ButtonMinus
        '
        Me.ButtonMinus.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.ButtonMinus.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ButtonMinus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMinus.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMinus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonMinus.Location = New System.Drawing.Point(293, 215)
        Me.ButtonMinus.Name = "ButtonMinus"
        Me.ButtonMinus.Size = New System.Drawing.Size(90, 52)
        Me.ButtonMinus.TabIndex = 9
        Me.ButtonMinus.Text = "-"
        Me.ButtonMinus.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(8, 273)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(89, 52)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "1"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(103, 273)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(89, 52)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "2"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button3.Location = New System.Drawing.Point(198, 273)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(89, 52)
        Me.Button3.TabIndex = 12
        Me.Button3.Text = "3"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'ButtonMult
        '
        Me.ButtonMult.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.ButtonMult.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ButtonMult.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMult.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMult.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonMult.Location = New System.Drawing.Point(293, 273)
        Me.ButtonMult.Name = "ButtonMult"
        Me.ButtonMult.Size = New System.Drawing.Size(90, 52)
        Me.ButtonMult.TabIndex = 13
        Me.ButtonMult.Text = "*"
        Me.ButtonMult.UseVisualStyleBackColor = False
        '
        'ButtonPoint
        '
        Me.ButtonPoint.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.ButtonPoint.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ButtonPoint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonPoint.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonPoint.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonPoint.Location = New System.Drawing.Point(103, 331)
        Me.ButtonPoint.Name = "ButtonPoint"
        Me.ButtonPoint.Size = New System.Drawing.Size(89, 56)
        Me.ButtonPoint.TabIndex = 14
        Me.ButtonPoint.Text = ","
        Me.ButtonPoint.UseVisualStyleBackColor = False
        '
        'ButtonEqual
        '
        Me.ButtonEqual.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.ButtonEqual.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ButtonEqual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonEqual.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonEqual.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonEqual.Location = New System.Drawing.Point(293, 331)
        Me.ButtonEqual.Name = "ButtonEqual"
        Me.ButtonEqual.Size = New System.Drawing.Size(90, 56)
        Me.ButtonEqual.TabIndex = 15
        Me.ButtonEqual.Text = "="
        Me.ButtonEqual.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.NumberLabel, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonPoint, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Button1, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Button2, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Button3, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonMult, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonMinus, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Button6, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Button5, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Button4, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Button7, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Button8, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Button9, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonMore, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonCE, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Button0, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonEqual, 3, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Button10, 2, 5)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, -1)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.Padding = New System.Windows.Forms.Padding(5)
        Me.TableLayoutPanel1.RowCount = 6
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.81417!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.23619!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.23619!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.23619!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.23619!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.24107!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(391, 395)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button10.Location = New System.Drawing.Point(198, 331)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(89, 56)
        Me.Button10.TabIndex = 17
        Me.Button10.Text = "+/-"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'ButtonCE
        '
        Me.ButtonCE.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.ButtonCE.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ButtonCE.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonCE.ForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonCE.Location = New System.Drawing.Point(293, 99)
        Me.ButtonCE.Name = "ButtonCE"
        Me.ButtonCE.Size = New System.Drawing.Size(90, 52)
        Me.ButtonCE.TabIndex = 18
        Me.ButtonCE.Text = "CE"
        Me.ButtonCE.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(61, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(78, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(390, 392)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button0 As Button
    Friend WithEvents NumberLabel As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Button10 As Button
    Friend WithEvents ButtonEqual As Button
    Friend WithEvents ButtonPoint As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents ButtonMult As Button
    Friend WithEvents ButtonMinus As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents ButtonMore As Button
    Friend WithEvents ButtonCE As Button
End Class
